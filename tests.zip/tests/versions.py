import pytest
import urllib3

from bedrock.versions import Version, Versions


version = Versions.get_by_version("1.8.0.24")
print(version)